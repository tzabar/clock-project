                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:200895
Mini 3-Axis CNC v0.29 by MakerBlock is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

UPDATE: Check out my drawing robot blog for the software to run this robot!  http://www.plotterbot.com  

Github link to Arduino code for TinyCNC: http://shor.tw/110  

Step by step instructions for v0.29 here: http://shor.tw/10d  

This is a small DIY 3-axis CNC.  It basically consists of 8 plastic parts (1 part is duplicated, so only 7 unique parts), three micro servos.  You will also need 1 zip tie, 1 rubberband, and a pen of your choice.  

Join my drawing robot newsletter http://shor.tw/x6 or check out my blog http://PlotterBot.com for more information, build instructions, updates, and improvements.  

I've uploaded an 8th STL file with all the parts arranged for printing at once on a Replicator 1.  ;)